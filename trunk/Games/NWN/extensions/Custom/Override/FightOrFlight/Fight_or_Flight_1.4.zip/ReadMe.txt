FIGHT_OR_FLIGHT 1.2
A basic morale system by Jeff Peterson
bucklehead@yahoo.com
======================================
Scripts included in the .erf:
*FIGHT_OR_FLIGHT
*FOF_SET
*FOF_LIBRARY
*NW_C2_DEFAULT4 (Modified)
*NW_C2_DEFAULT6 (Modified)
*NW_C2_DEFAULT7 (Modified)
*NW_C2_DEFAULT9 (Modified)

You may get an error message regarding FOF_LIBRARY when you try to import this 
.erf. This is because the script is a library file, and not a compiled script in 
its own right. Just keep importing and everything should turn out OK. 
======================================
I�ve long thought a system of basic morale checks was wanting from NWN. I mean, 
consider the goblin: a craven creature if ever there was one; yet it will stand 
and fight unto its own death against terrible odds. 
	Unfortunately, I was not able to find a system that  worked the way I 
wanted it. Flight should not only be a function of how many of your allies have 
been killed, but by how you stand against your individual opponent, and how your 
group is faring relative to your enemy�s group. In this spirit, I made a 
mathematical model which seems to work fairly well. 
	First, I modified the default OnSpawn (nw_c2_default9) to call a new 
script, �fof_set,� which determines whether a creature should have a 
FIGHT_OR_FLIGHT int set OnSpawn. This int will only be set if a creature is non-
undead, non-construct, has an intelligence greater than 5, has 5 or fewer hit 
dice, and has none of the standard fear-immunity feats, such as Aura of Courage. 
Dominated creatures will be excluded later. 
	The �fof_set� script also makes a determination as to the battle-hardiness 
of a creature. Creatures of 1-2 HD are considered �green,� and will fly at the 
drop of a hat. Those with 3-4 HD are considered �seasoned,� and it will take a 
little more to shake them up. Creatures with 5 HD are considered �veteran,� and 
will only flee if things are really not going their way. An important float 
variable, fRaw, which is used as the base of the key denominator, is determined 
by this assignment: Green creatures have fRaw = 3.0, seasoned ones have fRaw = 
4.0, veterans have fRaw = 5.0.
	The core FIGHT_OR_FLIGHT script will be called by a creature�s OnDamaged 
event, and also on the death or retreat of a compatriot. In brief, the script: 

1) Calculates a relative individual HD or CR. Thus, if a 1-CR goblin was damaged 
by a 3-HD fighter, the relative figure is 0.33. 
2) Calculates a relative group HD or CR. Thus, if six  1-CR goblins are fighting 
a single 3 HD fighter, the relative figure is 2.00. 
3) These figures are added to a base (ranging from 3-5), and then an HP �floor� 
is calculated based on the individual creature�s max HP. The formula is MaxHP * 
(1/(4 + indiv + group)), and so in our example it would be MaxHP * (1/(3 + 0.33 
+ 2.00)), or MaxHP * 0.1876. The result is rounded down to an integer. 
4) If a creature�s HP falls to or below this floor (and if its own HP level is 
worse than its individual opponent�s--creatures will try to win their single 
combats before retreating), it must make a will save or flee. In the case of 
equally matched individuals and groups, this HP floor is 1/6 of max hit points. 
The will save is also modified by these factors, and in an equal match the 
figure is 10.
5) A retreating creature will then scan the vicinity for a leader (marked as 
such by uncommenting a line in nw_c2_default9) or a rallying point (a waypoint 
or other object with tag �RallyingPoint�). They will run to the leader first, 
and the waypoint in the absence of a leader (assuming the Rally point is 
meaningfully far away). In the absence of either, they will simply run away. 
After they complete their flight, they will be commandable again (having 
mastered themselves), and may reenter combat.
6) Retreating creatures (and ones that are killed) make a silent shout to their 
compatriots. This sparks them to make their own fight_or_flight checks; as a 
result, the death or serious injury of one creature at the hands of a strong 
PC/party can lead to an entire group of foes to head for the hills. 

In this logic, a mass of creatures will stick it out against a few tough guys, 
but will run if the situation is reversed. A strong creature will wade in 
against many if the odds are in its favor, but will turn if things aren�t going 
its way. 
	There is much room for customization, if you want to include your own 
shouts or mess with the math to make creatures more or less cowardly. Further 
down the road, I will also likely come up with something for leaders to call for 
help from their troops, but you can do this if you�re in the mood, gentle 
scripter. 
	More updates and improvements are in the works, but I wanted to get this 
out there to gauge consumer sentiment, so to speak. Feel free to contact me at 
bucklehead@yahoo.com with any questions or comments (or, more importantly, new 
possibilities). Enjoy!
======================================
Version info:
1.0: First release, basic math model and retreat functions on damaged creatures 
only. 
1.2: Added the shout system mentioned in #6 above, which seems to have led to 
more complex group behaviors. Also made the example module a little more 
detailed, and added a goblin cave to illustrate the Leaders option. A 
Green/Seasoned/Veteran �toughness� feature was added via the fof_set script. If 
you want to disable this, I recommend using an all-purpose fRaw of 4.0.
1.4: Commented out the retreat SpeakStrings from the SignalFlee() function in 
fof_library. You can do with these what you want. Retreating creatures without a 
leader or rallying point will disappear after they reach their retreating range, 
so it makes sense to chase the ones you want. I also made a couple of minor 
fixes, especially relating to the unwanted retreating of Curst creatures. 
Finally, leaders will call out for help to nearby subordinates if they have 
taken much damage but succeed in their will saves. 

I also hope to get to work on some routines to keep retreating creatures from 
running smack into the area boundaries, and keep them from getting stuck in 
corners. No promises, though...
======================================
PS: A reviewer had suggested that I include something for the OnPerception as 
well, noting that weak creatures should flee at the very sight of a strong PC 
headed their way. I gave this a great deal of thought and have decided against 
it. In part, this is because I feel like I�ve messed with too many of the 
default scripts as it is, but mostly it was the sense that, in the heart of the 
monster, hope springs eternal that a quick strike can bring down even the 
doughtiest opponent. 
